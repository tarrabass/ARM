/**
 
 Pour utiliser:
 
 - dessiner des traits
 - pour les �diter, appuye sur 'e' pour entrer dans le mode �dition (rappuyer sur 'e' pour sortir du mode �dition)
 - les fl�ches haut ou bas pour changer le trait � �diter
 - les fl�ches gauche ou droit pour changer le point du trait � �diter
 - pour supprimer un trait faut appuyer sur 'd' (dans le mode �dition)
 
 
 Mapper les touches dans fonction keyPressed
 
 Utiliser effectSelection pour faire appel au draw des fonctions d'effet
 
 */

#include "testApp.h"

//--------------------------------------------------------------
void testApp::setup(){	
	useMSAA = false;
	fbo.setup(320, 240, GL_RGBA,0);
	/*
	shader.setup("proj.vs", "proj.fs");
	shader.begin();
	shader.setUniform1i("tex0", 0);
	shader.setUniform1i("tex1", 1);
	shader.end();
	 */
	ofEnableAlphaBlending();
	ofEnableSmoothing();
	glEnable(GL_LINE_SMOOTH);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	ofBackground(0, 0, 0);
	ofSetFrameRate(60);
	editMode = false;
	curLineEdit = 0;
	curPointEdit = 0;
	curQuadEdit = 0;
	curEffect = 0;
	quadMode = false;
	createMode = false;
	///// Sound Analyse /////
	numBands = 256;
	ofSoundStreamSetup(0,2,this, 44100, numBands, 4);	
	left = new float[numBands];
	myDiv = 10;
	////////////////////////	
}

//--------------------------------------------------------------
void testApp::update(){
	float totalFFT = 0;
	for(int i=0; i<numBands; i++){
		//		totalFFT += fftList[i]*50;
		totalFFT += left[i]*10;
	}
	averFFT = totalFFT / numBands;
	int soundVelocity =  abs((int)(averFFT*100));
	float soundVelocityVoulu = ((float)soundVelocity/100);
	float diff = soundVelocityVoulu - myDiv;
	myDiv += diff / 10;
	
	//update film
	for(int i=0; i<quads.size(); i++){
		quads[i].idleMovie();
	}
}

//--------------------------------------------------------------
void testApp::draw(){
	fbo.begin();
		glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
	drawScene(0, 0, 320, 240);
	fbo.end();

	if(!editMode && createMode){
		//Affiche l'effect choisi.
		curLine.draw();
		curQuad.draw(fbo,shader);
	}
	
	effectSelection();
}

//// test for FBO 

void testApp::drawScene(float x, float y, float w, float h) {
	glColor3f(1, 1, 1);
	///vidGrabber.draw(x, y, w, h);
	ofRect(0, 0, 320, 240);
	glColor3f(1, 0, 0);
	ofCircle(x + w * (0.5 + 0.5 * sin(ofGetElapsedTimef())), y + h * (0.5 + 0.5 * cos(ofGetElapsedTimef())), 10);
	glPushMatrix();
	glTranslatef(x, y, 0);
	glScalef(w/1024.0, h/768.0, 1);		// coordinates below were for 1024x768 screen
	
	static float counter = 0;
	
	//--------------------------- circles
	//let's draw a circle:
	ofSetColor(255,130,0);
	float radius = 50 + 10 * sin(counter);
	ofFill();		// draw "filled shapes"
	ofCircle(100,400,radius);
	
	// now just an outline
	ofNoFill();
	ofSetHexColor(0xCCCCCC);
	ofCircle(100,400,80);
	
	//--------------------------- rectangles
	ofFill();
	for (int i = 0; i < 200; i++){
		ofSetColor((int)ofRandom(0,255),(int)ofRandom(0,255),(int)ofRandom(0,255));
		ofRect(ofRandom(250,350),ofRandom(350,450),ofRandom(10,20),ofRandom(10,20));
	}
	
	//---------------------------  transparency
	ofSetHexColor(0x00FF33);
	ofRect(400,350,100,100);
	ofSetColor(255,0,0,127);   // red, 50% transparent
	ofRect(450,430,100,33);
	ofSetColor(255,0,0,(int)(counter * 10.0f) % 255);   // red, variable transparent
	ofRect(450,370,100,33);
	
	//---------------------------  lines
	ofSetHexColor(0xFF0000);
	for (int i = 0; i < 20; i++){
		ofLine(600,300 + (i*5),800, 250 + (i*10));
	}
	
	glPopMatrix();
	
}




//--------------------------------------------------------------
void testApp::keyPressed(int key){
	if(key == OF_KEY_UP && editMode){
		if(quadMode){
			curQuadEdit++;
			if(curQuadEdit == quads.size()){
				curQuadEdit = 0;
			}
		}
		else{
			curLineEdit++;
			if(curLineEdit == lines.size()){
				curLineEdit = 0;
			}
		}
	}
	else if(key == OF_KEY_DOWN && editMode){
		if(quadMode){
			curQuadEdit--;
			if(curQuadEdit == -1){
				curQuadEdit = quads.size()-1;
			}
		}
		else{
			curLineEdit--;
			if(curLineEdit == -1){
				curLineEdit = lines.size()-1;
			}
		}
	}
	else if(key == OF_KEY_RIGHT && editMode){
		if(quadMode){
			curPointEdit++;
			if(curPointEdit == 4){
				curPointEdit = 0;
			}
		}
		else{
			curPointEdit = 1;
		}
	}
	else if(key == OF_KEY_LEFT && editMode){
		if(quadMode){
			curPointEdit--;
			if(curPointEdit == -1){
				curPointEdit = 3;
			}
		}
		else{
			curPointEdit = 0;
		}
	}
	else if(key == 'e'){
		if (editMode){
			editMode = false;
			curLine.x1 = 0;
			curLine.x2 = 0;
			curLine.y1 = 0;
			curLine.y2 = 0;
		}
		else{
			editMode = true;
			curLineEdit = 0;
			curPointEdit = 0;
			curQuadEdit = 0;
			
			//Repasse en mode sans effets
			curEffect = 0;
		}
	}
	else if(key == 'd'){
		if(editMode){
			if(quadMode){
				if(curQuadEdit == quads.size()){
					curQuadEdit--;
				}
			}
			else{
				lines.erase(lines.begin() + curLineEdit);
				if(curLineEdit == lines.size()){
					curLineEdit--;
				}
			}
		}
	}
	else if(key == '0'){
		curEffect = 0;
	}
	else if(key == 'q'){
		if(quadMode){
			quadMode = false;
		}
		else{
			quadMode = true;
		}
	}
	else if(key == 'v'){
		std::stringstream ss;
		ss << curQuadEdit;
		string fileName = ss.str() + ".mov";
		
		ofVideoPlayer* tmp = new ofVideoPlayer();
		videos.push_back(tmp);
		videos.at(videos.size()-1)->loadMovie(fileName);
		videos.at(videos.size()-1)->play();
		
		quads[curQuadEdit].loadMovie(videos.at(videos.size()-1));
	}
	//Ajouter les autres effets ici en mappant d'autres touches
	switch (key) {
		case '1':
			//Variable pour dire quel effets est s�lectionn�
			curEffect = 1;
			//Applique l'effet sur la liste des vecteurs
			ef1.apply(lines);
			break;
		case '2':
			//Variable pour dire quel effets est s�lectionn�
			curEffect = 2;
			//Applique l'effet sur la liste des vecteurs
			ef2.apply(lines);
			break;
		case '3':
			curEffect = 3;
			ef3.apply(lines);
			break;
			
		case '4':
			curEffect = 4;
			ef4.apply(lines);
			break;

		case 'f':
			bFullscreen = !bFullscreen;
			
			if(!bFullscreen){
				ofSetWindowShape(1024,768);
				ofSetFullscreen(false);
				// figure out how to put the window in the center:
				
				ofSetWindowPosition(0, 0);
			} else if(bFullscreen == 1){
				
				ofSetFullscreen(true);
				//screenW-=200;
				ofSetWindowPosition(1024, 768);
				
			}
			break;
			
		case 'p':
			
			if(defromPerlin){
				
				defromPerlin = false;
				
			}else{
			
				defromPerlin = true;
			}
				break;
			}
	
}

//--------------------------------------------------------------
void testApp::keyReleased(int key){
}

//--------------------------------------------------------------
void testApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void testApp::mouseDragged(int x, int y, int button){
	if(!editMode){
		if(quadMode){
			curQuad.updateP2(mouseX, curQuad.y1);
			curQuad.updateP3(mouseX, mouseY);
			curQuad.updateP4(curQuad.x1, mouseY);
		}
		else{
			curLine.updateP2(mouseX, mouseY);
		}
	}
	else{
		if(quadMode){
			if(curPointEdit == 0){
				quads[curQuadEdit].updateP1(mouseX, mouseY);
			}
			else if(curPointEdit == 1){
				quads[curQuadEdit].updateP2(mouseX, mouseY);
			}
			else if(curPointEdit == 2){
				quads[curQuadEdit].updateP3(mouseX, mouseY);
			}
			else{
				quads[curQuadEdit].updateP4(mouseX, mouseY);
			}
		}
		else{
			if(curPointEdit == 0){
				lines[curLineEdit].updateP1(mouseX, mouseY);
			}
			else{
				lines[curLineEdit].updateP2(mouseX, mouseY);
			}
		}
	}

}

//--------------------------------------------------------------
void testApp::mousePressed(int x, int y, int button){
	if(!editMode){
		createMode = true;
		if(quadMode){
			curQuad.create(mouseX, mouseY);
			curQuad.videoOn = false;
		}
		else{
			curLine.create(mouseX, mouseY);
		}
	}
}

//--------------------------------------------------------------
void testApp::mouseReleased(int x, int y, int button){
	if(!editMode){
		createMode = false;
		if(quadMode){
			if((curQuad.x1 != curQuad.x2) || (curQuad.y1 != curQuad.y2)){
				quads.push_back(curQuad);
			}
		}
		else{
			if((curLine.x1 != curLine.x2) || (curLine.y1 != curLine.y2)){
				lines.push_back(curLine);
			}
		}
	}
}

//--------------------------------------------------------------
void testApp::windowResized(int w, int h){

}

/*
	Effect: ajouter les autres effets ici avec le case
 */
void testApp::effectSelection(){
	switch (curEffect) {
		//Pas d'effets, affiche les lignes normales

		case 0:
			for(int i=0; i<lines.size(); i++){
				if(i == curLineEdit && editMode && !quadMode){
					lines[i].draw();
					lines[i].drawPoint(curPointEdit);
				}
				else {
					lines[i].draw();
				}
			}
			
			//Quad
			drawQuads();
			break;
		//Effet 1
		case 1:
			ef1.draw(myDiv,defromPerlin);
			drawQuads();
			break;
		case 2:
			ef2.draw(myDiv,defromPerlin);
			drawQuads();
			break;
		case 3:
			ef3.draw(myDiv,defromPerlin,left);
			drawQuads();
			break;
		case 4:
			ef4.draw(myDiv,defromPerlin,left);
			drawQuads();
			break;
		default:
			break;
	}
}


void testApp::drawQuads(){
	for(int i=0; i<quads.size(); i++){
		if(i == curQuadEdit && editMode && quadMode){
			quads[i].draw(fbo,shader);
			quads[i].drawPoint(curPointEdit);
		}
		else{
			quads[i].draw(fbo,shader);
		}
	}
}


void testApp::audioReceived(float * input, int bufferSize, int nChannels){	
	// samples are "interleaved"
	for (int i = 0; i < bufferSize; i++){
		left[i] = input[i*2];
	}
}
